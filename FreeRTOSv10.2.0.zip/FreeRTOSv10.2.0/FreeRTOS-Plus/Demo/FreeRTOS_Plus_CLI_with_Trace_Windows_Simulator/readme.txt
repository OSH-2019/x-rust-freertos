Directories:

+ FreeRTOS-Plus/Demo_Projects_Using_FreeRTOS_Simulator/FreeRTOS_Plus_CLI_with_Trace
  contains a FreeRTOS windows simulator demo project for both FreeRTOS+CLI and
  FreeRTOS+Trace.  See http://www.FreeRTOS.org/trace for information on using
  the project.
  
